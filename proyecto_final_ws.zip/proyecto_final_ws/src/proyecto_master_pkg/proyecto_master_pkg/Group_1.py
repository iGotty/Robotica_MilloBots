import rclpy
from rclpy.node import Node
import RPi.GPIO as GPIO
import Adafruit_PCA9685
import time
from proyecto_interfaces.srv import StartNavigationTest
from proyecto_interfaces.srv import StartPerceptionTest
from proyecto_interfaces.srv import StartManipulationTest
from std_msgs.msg import Int32


class Group1Node(Node):
    def __init__(self):
        super().__init__('group_1')
        #Movimiento
        self.pwm = Adafruit_PCA9685.PCA9685()
        self.pwm.set_pwm_freq(50)
        self.Motor_A_EN    = 4
        self.Motor_B_EN    = 17

        self.Motor_A_Pin1  = 14
        self.Motor_A_Pin2  = 15
        self.Motor_B_Pin1  = 27
        self.Motor_B_Pin2  = 18
        self.INCREMENT = 5
        self.DELAY = 0.1
        
        self.angulo13=35
        self.angulo12=55
        self.pos_servo12 = 100
        self.pos_servo13 = 100
        self.pos_servo15 = 100
        self.Dir_forward   = 0
        self.Dir_backward  = 1

        self.left_forward  = 0
        self.left_backward = 1

        self.right_forward = 0
        self.right_backward= 1

        self.pwn_A = 0
        self.pwm_B = 0
        self.setup_motors()

        # MANIPULACION
        self.pos_servo12 = 100
        self.pos_servo13 = 100
        self.pos_servo15 = 100
        # Percepción
        self.publisher_banner = self.create_publisher(Int32, '/banner_actual', 10)
        # Servicios
        self.nav_srv = self.create_service(StartNavigationTest, '/group_1/start_navigation_test_srv', self.nav_callback)
        self.perception_srv = self.create_service(StartPerceptionTest, '/group_1/start_perception_test_srv', self.perception_callback)
        self.manipulation_srv = self.create_service(StartManipulationTest, '/group_1/start_manipulation_test_srv', self.manipulation_callback)
    def motorStop(self):#Motor stops
        GPIO.output(self.Motor_A_Pin1, GPIO.LOW)
        GPIO.output(self.Motor_A_Pin2, GPIO.LOW)
        GPIO.output(self.Motor_B_Pin1, GPIO.LOW)
        GPIO.output(self.Motor_B_Pin2, GPIO.LOW)
        GPIO.output(self.Motor_A_EN, GPIO.LOW)
        GPIO.output(self.Motor_B_EN, GPIO.LOW)
    
    def setup_motors(self):
        global pwm_A, pwm_B
        GPIO.setwarnings(False)
        GPIO.setmode(GPIO.BCM)
        GPIO.setup(self.Motor_A_EN, GPIO.OUT)
        GPIO.setup(self.Motor_B_EN, GPIO.OUT)
        GPIO.setup(self.Motor_A_Pin1, GPIO.OUT)
        GPIO.setup(self.Motor_A_Pin2, GPIO.OUT)
        GPIO.setup(self.Motor_B_Pin1, GPIO.OUT)
        GPIO.setup(self.Motor_B_Pin2, GPIO.OUT)

        self.motorStop()
        try:
            pwm_A = GPIO.PWM(self.Motor_A_EN, 1000)
            pwm_B = GPIO.PWM(self.Motor_B_EN, 1000)
        except:
            pass
    
    def motor_left(self,status, direction, speed):#Motor 2 positive and negative rotation
        if status == 0: # stop
            GPIO.output(self.Motor_B_Pin1, GPIO.LOW)
            GPIO.output(self.Motor_B_Pin2, GPIO.LOW)
            GPIO.output(self.Motor_B_EN, GPIO.LOW)
        else:
            if direction == self.Dir_backward:
                GPIO.output(self.Motor_B_Pin1, GPIO.HIGH)
                GPIO.output(self.Motor_B_Pin2, GPIO.LOW)
                pwm_B.start(100)
                pwm_B.ChangeDutyCycle(speed)
            elif direction == self.Dir_forward:
                GPIO.output(self.Motor_B_Pin1, GPIO.LOW)
                GPIO.output(self.Motor_B_Pin2, GPIO.HIGH)
                pwm_B.start(0)
                pwm_B.ChangeDutyCycle(speed)


    def motor_right(self,status, direction, speed):#Motor 1 positive and negative rotation
        if status == 0: # stop
            GPIO.output(self.Motor_A_Pin1, GPIO.LOW)
            GPIO.output(self.Motor_A_Pin2, GPIO.LOW)
            GPIO.output(self.Motor_A_EN, GPIO.LOW)
        else:
            if direction == self.Dir_forward:#
                GPIO.output(self.Motor_A_Pin1, GPIO.HIGH)
                GPIO.output(self.Motor_A_Pin2, GPIO.LOW)
                pwm_A.start(100)
                pwm_A.ChangeDutyCycle(speed)
            elif direction == self.Dir_backward:
                GPIO.output(self.Motor_A_Pin1, GPIO.LOW)
                GPIO.output(self.Motor_A_Pin2, GPIO.HIGH)
                pwm_A.start(0)
                pwm_A.ChangeDutyCycle(speed)
        return direction


    def move(self,speed, direction, turn, radius=0.6):   # 0 < radius <= 1  
        
        #speed = 100
        if direction == 'forward':
            if turn == 'right':
                self.motor_left(0, self.left_backward, int(speed*radius))
                self.motor_right(1, self.right_forward, speed)
            elif turn == 'left':
                self.motor_left(1, self.left_forward, speed)
                self.motor_right(0, self.right_backward, int(speed*radius))
            else:
                self.motor_left(1, self.left_forward, speed)
                self.motor_right(1, self.right_forward, speed)
        elif direction == 'backward':
            if turn == 'right':
                self.motor_left(0, self.left_forward, int(speed*radius))
                self.motor_right(1, self.right_backward, speed)
            elif turn == 'left':
                self.motor_left(1, self.left_backward, speed)
                self.motor_right(0, self.right_forward, int(speed*radius))
            else:
                self.motor_left(1, self.left_backward, speed)
                self.motor_right(1, self.right_backward, speed)
        elif direction == 'no':
            if turn == 'right':
                self.motor_left(1, self.left_backward, speed)
                self.motor_right(1, self.right_forward, speed)
            elif turn == 'left':
                self.motor_left(1, self.left_forward, speed)
                self.motor_right(1, self.right_backward, speed)
            else:
                self.motorStop()
        else:
            pass

    def garra(self,accion):
        # Define some constants
        
        
        if accion == 'abrir_garra':  
            self.pos_servo15 += self.INCREMENT
            print(self.pos_servo15)
            self.pos_servo15 = min(self.pos_servo15, 220)  # Limita el valor máximo a 220.
            self.pwm.set_pwm(15, 0, self.pos_servo15)
            time.sleep(self.DELAY)
        elif accion == 'cerrar_garra': 
            print('cerrar_garra')
            self.pos_servo15 -= self.INCREMENT
            print(self.pos_servo15)
            self.pos_servo15 = max(self.pos_servo15, 100)  # Limita el valor mínimo a 100.
            self.pwm.set_pwm(15, 0, self.pos_servo15)
            time.sleep(self.DELAY)
        elif accion == 'abrir_13':  
            print('abrir13')
            self.pos_servo13 += self.INCREMENT
            print(self.pos_servo13)
            self.pos_servo13 = min(self.pos_servo13, 510)
            self.pwm.set_pwm(13, 0, self.pos_servo13)
            time.sleep(self.DELAY)
        elif accion == 'cerrar_13':  
            print('cerrar13')
            self.pos_servo13 -= self.INCREMENT
            print(self.pos_servo13)
            self.pos_servo13 = max(self.pos_servo13, 100)
            self.pwm.set_pwm(13, 0, self.pos_servo13)
            time.sleep(self.DELAY)
        elif accion == 'abrir_12':  
            print('abrir12')
            self.pos_servo12 += self.INCREMENT
            self.pos_servo12 = min(self.pos_servo12, 205)
            print(self.pos_servo12)
            self.pwm.set_pwm(12, 0, self.pos_servo12)
            time.sleep(self.DELAY)
        elif accion == 'cerrar_12': 
            print('cerrar12')
            print(self.INCREMENT)
            self.pos_servo12 -= self.INCREMENT
            print(self.pos_servo12)
            self.pos_servo12 = max(self.pos_servo12, 100)
            self.pwm.set_pwm(12, 0, self.pos_servo12)
            time.sleep(self.DELAY)

    def nav_callback(self, request, response):
        if True:
            response.answer = "El servicio de navegación fue aprobado"
            self.start_navigation()
        else:
            response.answer = "El servicio de navegación no fue aprobado"
        return response

    def perception_callback(self, request, response):
        # Asumiendo que tienes un método que pueda tratar con la percepción en tu aplicación.
        if request.banner_a==1:
            coordinates_a="(0.375,0.515)"
        elif request.banner_a==2:
            coordinates_a="(0.7525,1.0175)"
        elif request.banner_a==3:
            coordinates_a="(0.245,0.9775)"
        if request.banner_b==1:
            coordinates_b="(0.375,0.515)"
        elif request.banner_b==2:
            coordinates_b="(0.7525,1.0175)"
        elif request.banner_b==3:
            coordinates_b="(0.245,0.9775)"
        
        if request.banner_a==3:
            self.publisher_banner.publish(Int32, 3)
            self.move(80,"forward","no",0.8)
            time.sleep(0.33)
            self.motorStop()
            self.publisher_banner.publish(Int32, 3)

        elif request.banner_a==2:
            self.publisher_banner.publish(Int32, 2)
            self.move(80,"forward","no",0.8)
            time.sleep(0.33)
            self.motorStop()
            self.move(80,"forward","no",0.8)
            time.sleep(0.33)
            self.motorStop()
            self.publisher_banner.publish(Int32, 2)

        elif request.banner_a==1:
            self.publisher_banner.publish(Int32, 1)
            self.move(80,"forward","no",0.8)
            time.sleep(0.33)
            self.motorStop()
            self.move(80,"forward","no",0.8)
            time.sleep(0.33)
            self.motorStop()
            self.move(80,"forward","no",0.8)
            time.sleep(0.33)
            self.motorStop()
            self.publisher_banner.publish(Int32, 1)
            
        time.sleep(40)
        if request.banner_b==3:
            self.publisher_banner.publish(Int32, 3)
            self.move(80,"forward","no",0.8)
            time.sleep(0.33)
            self.motorStop()
            self.move(80,"forward","no",0.8)
            time.sleep(0.33)
            self.motorStop()
            self.move(80,"forward","no",0.8)
            time.sleep(0.33)
            self.motorStop()
            self.publisher_banner.publish(Int32, 3)
        elif request.banner_b==2:
            self.publisher_banner.publish(Int32, 2)
            self.move(80,"forward","no",0.8)
            time.sleep(0.33)
            self.motorStop()
            self.move(80,"forward","no",0.8)
            time.sleep(0.33)
            self.motorStop()
            self.publisher_banner.publish(Int32, 2)

        elif request.banner_b==1:
            self.publisher_banner.publish(Int32, 1)
            self.move(80,"forward","no",0.8)
            time.sleep(0.33)
            self.motorStop()
            self.publisher_banner.publish(Int32, 1)
     
        response.answer = f"Debo identificar el banner a que se encuentra en las coordenadas {coordinates_a} y el banner b que se encuentra en las coordenadas {coordinates_b}"
        return response
    
    def mover_a_posicion_inicial(self):
        self.pwm.set_pwm(15, 0, 100)
        time.sleep(2)
        self.pwm.set_pwm(10, 0, 100)
        time.sleep(2)
        self.pwm.set_pwm(12, 0, 100)

    def manipulation_callback(self, request, response):

        if request.platform == 1:
            destination_platform = 2
            self.move(80,"forward","no",0.8)
            time.sleep(2)
            self.motorStop()
            self.move(80,"forward","left",0.8)
            time.sleep(1)
            self.motorStop()

            #TODO: CODIGO PARA MOVER Y CERRAR GARRA A 15 cm 

            self.mover_a_posicion_inicial()
            time.sleep(2)
            self.pwm.set_pwm(12, 0, 130)
            time.sleep(2)
            self.pwm.set_pwm(10, 0, 200)
            time.sleep(2)
            self.pwm.set_pwm(15, 0, 220)
            time.sleep(2)
            self.pwm.set_pwm(10, 0, 100)
            time.sleep(2)
            self.pwm.set_pwm(12, 0, 100)
            time.sleep(20)

            self.move(80,"forward","right",0.8)
            time.sleep(1)
            self.motorStop() 
            self.move(80,"forward","no",0.8)
            time.sleep(2)
            self.motorStop()
            self.move(80,"forward","right",0.8)
            time.sleep(1)
            self.motorStop() 

            #TODO: CODIGO PARA MOVER Y ABRIR GARRA A 10 cm CAMBIAR PARAMETROOOOOOOOOOOOOOOS
            self.pwm.set_pwm(12, 0, 130)
            time.sleep(2)
            self.pwm.set_pwm(10, 0, 212)
            time.sleep(2)
            self.pwm.set_pwm(15, 0, 100)
            time.sleep(2)
            self.mover_a_posicion_inicial()

        else:
            destination_platform = 1

            self.move(80,"forward","no",0.8)
            time.sleep(4)
            self.motorStop()
            self.move(80,"forward","right",0.8)
            time.sleep(1)
            self.motorStop()

            #TODO: CODIGO PARA MOVER Y CERRAR GARRA A 10 cm CAMBIAR PARAMETROOOOOOOOOOS

            self.mover_a_posicion_inicial()
            time.sleep(2)
            self.pwm.set_pwm(12, 0, 130)
            time.sleep(2)
            self.pwm.set_pwm(10, 0, 200)
            time.sleep(2)
            self.pwm.set_pwm(15, 0, 220)
            time.sleep(2)
            self.pwm.set_pwm(10, 0, 100)
            time.sleep(2)
            self.pwm.set_pwm(12, 0, 100)
            time.sleep(20)
             
            self.move(80,"forward","right",0.8)
            time.sleep(1)
            self.motorStop() 
            self.move(80,"forward","no",0.8)
            time.sleep(2)
            self.motorStop()
            self.move(80,"forward","right",0.8)
            time.sleep(1)
            self.motorStop() 

            #TODO: CODIGO PARA MOVER Y ABRIR GARRA A 15 cm 

            self.pwm.set_pwm(12, 0, 130)
            time.sleep(2)
            self.pwm.set_pwm(10, 0, 212)
            time.sleep(2)
            self.pwm.set_pwm(15, 0, 100)
            time.sleep(2)
            self.mover_a_posicion_inicial()


        response.answer = f"La ficha de tipo {request.x} se encuentra en la plataforma {request.platform} y la llevaré a la plataforma {destination_platform}"
        return response

    def start_navigation(self, x, y):
        # Asegúrate de implementar este método según tu necesidad.
        # Este es solo un placeholder para el ejemplo.
        # return navigation_success
        # Código para navegación autónoma del robot
        self.move(80, "forward", "no", 0.8)
        time.sleep(2)
        self.motorStop()
        self.move(80, "forward", "right", 0.8)
        time.sleep(1)
        self.motorStop()
        self.move(80, "forward", "no", 0.8)
        time.sleep(2)
        self.motorStop()
        self.move(80, "forward", "right", 0.8)
        time.sleep(1)
        self.motorStop()
        self.move(80, "forward", "no", 0.8)
        time.sleep(2)
        self.motorStop()
        self.move(80, "forward", "right", 0.8)
        time.sleep(1)
        self.motorStop()





def main(args=None):
    rclpy.init(args=args)

    node = Group1Node()

    rclpy.spin(node)

    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
