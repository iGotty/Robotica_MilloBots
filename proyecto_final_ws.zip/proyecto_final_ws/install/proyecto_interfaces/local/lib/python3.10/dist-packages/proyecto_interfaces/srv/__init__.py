from proyecto_interfaces.srv._start_manipulation_test import StartManipulationTest  # noqa: F401
from proyecto_interfaces.srv._start_navigation_test import StartNavigationTest  # noqa: F401
from proyecto_interfaces.srv._start_perception_test import StartPerceptionTest  # noqa: F401
