from proyecto_interfaces.msg._banner import Banner  # noqa: F401
