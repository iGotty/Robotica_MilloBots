// generated from rosidl_generator_c/resource/idl.h.em
// with input from proyecto_interfaces:srv/StartManipulationTest.idl
// generated code does not contain a copyright notice

#ifndef PROYECTO_INTERFACES__SRV__START_MANIPULATION_TEST_H_
#define PROYECTO_INTERFACES__SRV__START_MANIPULATION_TEST_H_

#include "proyecto_interfaces/srv/detail/start_manipulation_test__struct.h"
#include "proyecto_interfaces/srv/detail/start_manipulation_test__functions.h"
#include "proyecto_interfaces/srv/detail/start_manipulation_test__type_support.h"

#endif  // PROYECTO_INTERFACES__SRV__START_MANIPULATION_TEST_H_
