import pygame
from math import *
from PIL import Image
import tkinter.filedialog as filedialog
import os

def save_file():
    file_path = filedialog.asksaveasfilename(defaultextension=".png")
    if file_path:
        image = Image.open("screenshot.png")
        image.save(file_path)
        os.remove("screenshot.png")



pygame.init()
width, height = 700, 700
screen = pygame.display.set_mode((width, height))
position = [width // 2, height // 2]
radius = 20
color = (255, 0, 0)
trail = []
angle = -90

move_forward = False
move_backward = False
rotate_left = False
rotate_right = False
key_events = []

image_orig = pygame.image.load("millos.png")
image_orig = pygame.transform.scale(image_orig, (2 * radius, 2 * radius))
rotated_image = pygame.transform.rotate(image_orig, angle)
rotated_image = image_orig.copy()

button_width = 200
button_height = 50
button_x = width - button_width - 10
button_y = height - button_height - 10
button_rect = pygame.Rect(button_x, button_y, button_width, button_height)
font = pygame.font.Font(None, 36)
text = font.render("Guardar", 1, (255, 255, 255))
text_pos = text.get_rect(centerx=button_rect.centerx, centery=button_rect.centery)

def take_screenshot():
    # Obtener la captura de pantalla
    screenshot = pygame.surfarray.array3d(screen)
    # Guardar la captura de pantalla en un archivo
    im = Image.fromarray(screenshot).rotate(-90).transpose(Image.FLIP_LEFT_RIGHT)
    im.save("screenshot.png")
    save_file()
    
running = True

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        # Si se presiona una tecla, registrar el evento
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_w:
                move_forward = True
                key_events.append("w")
            if event.key == pygame.K_s:
                move_backward = True
                key_events.append("s")
            if event.key == pygame.K_q:
                rotate_left = True
                key_events.append("q")
            if event.key == pygame.K_e:
                rotate_right = True
                key_events.append("e")
        # Si se suelta una tecla, detener la acción correspondiente
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_w:
                move_forward = False
            if event.key == pygame.K_s:
                move_backward = False
            if event.key == pygame.K_q:
                rotate_left = False
            if event.key == pygame.K_e:
                rotate_right = False
    # Si se presiona el botón para tomar la captura de pantalla
        if event.type == pygame.MOUSEBUTTONDOWN:
        # Obtener la posición del cursor
            mouse_x, mouse_y = pygame.mouse.get_pos()
        # Verificar si el cursor está en la posición del botón
            # button_x, button_y, button_width, button_height
            if button_x < mouse_x < button_x + button_width and button_y < mouse_y < button_y + button_height:
                take_screenshot()
                

    
    # Establecer la velocidad de movimiento
    vel = 0.7
    rot_vel = 200
    # rotacion
    if rotate_left:
        angle = (angle - 90)
        rotated_image = pygame.transform.rotate(image_orig, -90-angle)
        pygame.time.delay(rot_vel) # Pausa de 100 milisegundos
    if rotate_right:
        angle = (angle + 90)
        rotated_image = pygame.transform.rotate(image_orig, -90-angle)
        pygame.time.delay(rot_vel) # Pausa de 100 milisegundos

    # calculo de movimiento y limitacion del mapa
    delta_x = round(vel * cos(radians(angle)),2)
    delta_y = round(vel * sin(radians(angle)),2)

    if move_forward and position[0] + delta_x + radius < width and position[1] + delta_y + radius < height:
        delta_x = vel * cos(radians(angle))
        delta_y = vel * sin(radians(angle))
        position[0] = min(max(position[0] + delta_x, radius), width - radius)
        position[1] = min(max(position[1] + delta_y, radius), height - radius)
    
    if move_backward and position[0] - delta_x - radius > 0 and position[1] - delta_y - radius > 0:
        delta_x = vel * cos(radians(angle + 180))
        delta_y = vel * sin(radians(angle + 180))
        position[0] = min(max(position[0] + delta_x, radius), width - radius)
        position[1] = min(max(position[1] + delta_y, radius), height - radius)
    #actualizacion al movimiento
    screen.fill((255, 255, 255))
    pygame.draw.rect(screen, (0, 0, 255), button_rect)
    screen.blit(text, text_pos)
    
    for pos in trail:
        pygame.draw.rect(screen, (0, 255, 0), (pos[0] - radius, pos[1] - radius, 2 * radius, 2 * radius))
    trail.append(position.copy())
    screen.blit(rotated_image, (position[0]-radius, position[1]-radius))
    pygame.display.update()



pygame.quit()
with open("key_events.txt", "w") as f:
    for key in key_events:
        f.write(f"{key}\n")





