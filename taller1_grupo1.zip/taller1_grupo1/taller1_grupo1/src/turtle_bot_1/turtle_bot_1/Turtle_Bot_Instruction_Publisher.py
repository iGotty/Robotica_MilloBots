import rclpy
import time
from rclpy.node import Node
from std_msgs.msg import String

class FileInstructionPublisher(Node):

    def __init__(self):
        super().__init__('file_instruction_publisher')
        self.publisher_ = self.create_publisher(String, 'instruction', 10)
        self.file_path = "archivofacil.txt"  
        self.read_and_publish_instructions()

    def read_and_publish_instructions(self):
        with open(self.file_path, 'r') as file:
            '''lineal_vel = float(file.readline())
            angular_vel = float(file.readline())'''

            for line in file:
                print(line)
                action_duration = line.strip()
                self.publisher_.publish(String(data=action_duration))
                _, duration = line.strip().split(',')
                time.sleep(float(duration))

def main(args=None):
    rclpy.init(args=args)
    file_instruction_publisher = FileInstructionPublisher()
    rclpy.spin(file_instruction_publisher)

if __name__ == '__main__':
    main()
