import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from std_msgs.msg import String
from pynput import keyboard
from pyfiglet import Figlet
import time
import RPi.GPIO as GPIO

class Turtle_Bot_Teleop(Node):

    def __init__(self):
        super().__init__('turle_bot_teleop')
        
        self.Motor1A = 23
        self.Motor1B = 24
        self.Motor2A = 6
        self.Motor2B = 5
        self.EN1 = 18
        self.EN2 = 19
        self.setup_motors()

        # Crear el publicador para el tópico /robot_cmdVel
        self.cmd_vel_pub = self.create_publisher(Twist, '/robot_cmdVel', 10)

        # Print cool
        self.fuente = Figlet(font="graffiti")
        print(self.fuente.renderText("Bienvenido!"))
        print(self.fuente.renderText("Hincha de millos!\n"))

        # Pedir al usuario las velocidades
        
        self.angular_vel = float(input("Ingrese la velocidad angular a la que quiere que el robot se mueva (0 a 1): "))
        self.lineal_vel = float(input("Ingrese la velocidad lineal a la que quiere que el robot se mueva (0 a 1): "))
        self.ruta = input("Ingrese la ruta en la que se va a guardar el recorrido: ")

        self.list_tics = []

        # Inicializar el listener del teclado
        listener = keyboard.Listener(
            on_press=self.on_press,
            on_release=self.on_release)
        listener.start()

    def setup_motors(self):
        GPIO.setmode(GPIO.BCM)
        GPIO.setwarnings(False)

        GPIO.setup(self.Motor1A, GPIO.OUT)
        GPIO.setup(self.Motor1B, GPIO.OUT)
        GPIO.setup(self.Motor2A, GPIO.OUT)
        GPIO.setup(self.Motor2B, GPIO.OUT)
        GPIO.setup(self.EN1, GPIO.OUT)
        GPIO.setup(self.EN2, GPIO.OUT)

        self.pwm_motor1 = GPIO.PWM(self.EN1, 100)
        self.pwm_motor2 = GPIO.PWM(self.EN2, 100)

        self.pwm_motor1.start(0)
        self.pwm_motor2.start(0)

    def adelante(self):
        print("El robot se esta moviendo adelante")
        self.pwm_motor1.ChangeDutyCycle(self.lineal_vel * 100)
        self.pwm_motor2.ChangeDutyCycle(self.lineal_vel * 100)
        GPIO.output(self.Motor1A,GPIO.LOW)
        GPIO.output(self.Motor1B,GPIO.HIGH)

        GPIO.output(self.Motor2A,GPIO.LOW)
        GPIO.output(self.Motor2B,GPIO.HIGH)
        
        

        # Publicar la velocidad actual en el tópico /robot_cmdVel
        cmd_vel_msg = Twist()
        cmd_vel_msg.linear.x = self.lineal_vel
        cmd_vel_msg.angular.z = 0.0
        self.cmd_vel_pub.publish(cmd_vel_msg)
    def atras(self):
        print("El robot se esta moviendo para atras")
        self.pwm_motor1.ChangeDutyCycle(self.lineal_vel * 100)
        self.pwm_motor2.ChangeDutyCycle(self.lineal_vel * 100)
        GPIO.output(self.Motor1A,GPIO.HIGH)
        GPIO.output(self.Motor1B,GPIO.LOW)

        GPIO.output(self.Motor2A,GPIO.HIGH)
        GPIO.output(self.Motor2B,GPIO.LOW)

        # Publicar la velocidad actual en el tópico /robot_cmdVel
        cmd_vel_msg = Twist()
        cmd_vel_msg.linear.x = -self.lineal_vel
        cmd_vel_msg.angular.z = 0.0
        self.cmd_vel_pub.publish(cmd_vel_msg)

    def girar_izquierda(self):
        print("El robot esta girando a la izquierda")
        self.pwm_motor1.ChangeDutyCycle(self.angular_vel * 100)
        self.pwm_motor2.ChangeDutyCycle(self.angular_vel * 100)
        GPIO.output(self.Motor1A,GPIO.HIGH)
        GPIO.output(self.Motor1B,GPIO.HIGH)

        GPIO.output(self.Motor2A,GPIO.LOW)
        GPIO.output(self.Motor2B,GPIO.HIGH)

        # Publicar la velocidad actual en el tópico /robot_cmdVel
        cmd_vel_msg = Twist()
        cmd_vel_msg.linear.x = 0.0
        cmd_vel_msg.angular.z = self.angular_vel
        self.cmd_vel_pub.publish(cmd_vel_msg)

    def girar_derecha(self):
        print("El robot esta girando a la derecha")
        self.pwm_motor1.ChangeDutyCycle(self.angular_vel * 100)
        self.pwm_motor2.ChangeDutyCycle(self.angular_vel * 100)
        GPIO.output(self.Motor1A,GPIO.LOW)
        GPIO.output(self.Motor1B,GPIO.HIGH)

        GPIO.output(self.Motor2A,GPIO.HIGH)
        GPIO.output(self.Motor2B,GPIO.HIGH)

        # Publicar la velocidad actual en el tópico /robot_cmdVel
        cmd_vel_msg = Twist()
        cmd_vel_msg.linear.x = 0.0
        cmd_vel_msg.angular.z = -self.angular_vel
        self.cmd_vel_pub.publish(cmd_vel_msg)

    def stop_motors(self):
        print("El robot se detiene")
        self.pwm_motor1.ChangeDutyCycle(0)
        self.pwm_motor2.ChangeDutyCycle(0)
        GPIO.output(self.Motor1B, GPIO.LOW)
        GPIO.output(self.Motor2B, GPIO.LOW)

        # Publicar la velocidad actual en el tópico /robot_cmdVel
        cmd_vel_msg = Twist()
        cmd_vel_msg.linear.x = 0.0
        cmd_vel_msg.angular.z = 0.0
        self.cmd_vel_pub.publish(cmd_vel_msg)
    def on_press(self,key):
        try:
            #Todo: asignar las teclas respectivas a una orden que permita al robot realizar una accion
            print('Buena Bro! Estas oprimiendo la tecla {0}'.format(
                key.char))
            if key.char=='w':
                self.adelante()
            if key.char=='s':
                self.atras()
            if key.char=='e':
                self.girar_derecha()
            if key.char=='q':
                self.girar_izquierda()
        except AttributeError:
            print('A que juegas brother? Deja de oprimir teclas raras, oprimiste la tecla {0}'.format(
                key))
    def on_release(self,key):
        print('Que lastimaa bro, dejaste de oprimir la tecla {0} '.format(
            key))
        try:
            if key.char=='w' or key.char=='s' or key.char=='e' or key.char=='q':
                self.stop_motors()
                
            if key == keyboard.Key.esc:
                # Stop listener
                return False
        except AttributeError:
            print('Que lastimaa bro, dejaste de oprimir la tecla {0} '.format(
            key))
	
    # (Resto del código)
def main(args=None):
    rclpy.init(args=args)

    turle_bot_teleop = Turtle_Bot_Teleop()

    rclpy.spin(turle_bot_teleop)
    
if __name__ == '__main__':
    print("Node initialized")
    main()
