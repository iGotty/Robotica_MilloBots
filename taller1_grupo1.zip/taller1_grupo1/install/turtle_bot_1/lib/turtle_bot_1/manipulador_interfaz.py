import pygame
import numpy as np

def mani_interfaz():
    # Dimensiones de la ventana de pygame
    WIDTH = 800
    HEIGHT = 600

    def leer_ultima_linea(archivo):
        with open(archivo, 'r') as file:
            lineas = file.readlines()
            ultima_linea = lineas[-1].strip()
            angulos = ultima_linea.split(',')
            angulo_1 = float(angulos[0])
            angulo_2 = float(angulos[1])
        return int(angulo_1), int(angulo_2)

    def dibujar_segmentos(screen, angulo_1, angulo_2):
        # Color de los segmentos
        color = (255, 255, 255)

        # Coordenadas y dibujo de los segmentos ...

        # Segmento 1
        x_start = WIDTH // 2
        y_start = HEIGHT // 1.2
        length = 200

        x_end = x_start + length * np.cos(np.radians(-angulo_1))
        y_end = y_start + length * np.sin(np.radians(-angulo_1))
        pygame.draw.line(screen, color, (x_start, y_start), (x_end, y_end), 2)

        # Segmento 2
        x_start_2 = x_end
        y_start_2 = y_end
        length_2 = 200

        x_end_2 = x_start_2 + length_2 * np.cos(np.radians(-(180 - angulo_2)))
        y_end_2 = y_start_2 + length_2 * np.sin(np.radians(-(180 - angulo_2)))
        pygame.draw.line(screen, color, (x_start_2, y_start_2), (x_end_2, y_end_2), 2)

    # Ruta del archivo .txt
    archivo_txt = 'mani.txt'

    # Inicializar pygame
    pygame.init()

    # Crear la ventana de pygame
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Segmentos")

    # Bucle principal de Pygame
    running = True
    clock = pygame.time.Clock()

    while running:
        # Control de eventos
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        # Leer la última línea del archivo
        angulo_1, angulo_2 = leer_ultima_linea(archivo_txt)

        # Dibujar los segmentos con los ángulos leídos
        screen.fill((0, 0, 0))
        dibujar_segmentos(screen, angulo_1, angulo_2)

        # Actualizar la pantalla
        pygame.display.flip()
        clock.tick(60)

    # Cerrar pygame
    pygame.quit()

mani_interfaz()
