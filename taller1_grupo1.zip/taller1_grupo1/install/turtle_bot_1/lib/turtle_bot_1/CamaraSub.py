import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from std_msgs.msg import String
from perception import *

class PerceptionNode(Node):
    def __init__(self):
        super().__init__("perception_node")
        self.banner_subscription = self.create_subscription( String,"banner",self.banner_callback,10)
        self.image_subscription = self.create_subscription(Image,"image_raw",self.image_callback,10)
        self.response_publisher = self.create_publisher(String,"respuesta_vision",10)

    def banner_callback(self, msg):
        # Aquí puedes procesar el mensaje del tópico "banner"
        banner_content = msg.data
        # Llamar a la función percep y publicar el resultado
        response = self.percep(banner_content, None)
        self.response_publisher.publish(response)

    def image_callback(self, msg):
        # Aquí puedes procesar el mensaje del tópico "image_raw"
        image_content = msg.data
        # Llamar a la función percep y publicar el resultado
        response = self.percep(None, image_content)
        self.response_publisher.publish(response)

    def percep(self, banner_content, image_content):
        # Aquí puedes realizar el procesamiento de la imagen y el contenido del banner
        # y devolver el resultado como un mensaje String
        if image_content is not None and banner_content is not None:
            res = f_per(image_content)
            return banner_content+","+res
        else:
            return "No hay imagen o banner"


def main(args=None):
    rclpy.init(args=args)
    perception_node = PerceptionNode()
    rclpy.spin(perception_node)
    perception_node.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()
