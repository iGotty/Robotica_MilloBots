import pygame
from math import *
from PIL import Image
import tkinter.filedialog as filedialog
import os

def save_file():
    file_path = filedialog.asksaveasfilename(defaultextension=".png")
    if file_path:
        image = Image.open("screenshot.png")
        image.save(file_path)
        os.remove("screenshot.png")

from math import sin, cos
import math
def cinematica_directa(w, r, d, modo, x0, y0, angle):
    # Inicializar las velocidades de las ruedas
    v_r = 0.0
    v_l = 0.0
    vmax = 2
    achange = 2
    w *= vmax
    # Determinar las velocidades de las ruedas según el modo de movimiento
    if modo == 'w' or modo == 's':
        v_r = v_l = w * r
        
    elif modo == 'e':
        v_r = 0.0
        v_l = w * r
        angle -= achange
        
    elif modo == 'q':
        v_r = w * r
        v_l = 0.0
        angle += achange

    # Calcular la velocidad promedio del robot
    v_promedio = (v_r + v_l) / 2

    # Calcular el cambio en la posición del robot en el plano XY
    delta_x = v_promedio * cos(angle*math.pi/180)
    delta_y = v_promedio * sin(angle*math.pi/180)

    if modo == 's':
        delta_x *= -1
        delta_y *= -1

    return delta_x + x0, delta_y + y0, angle

def run_interface():
    pygame.init()
    width, height = 700, 700
    screen = pygame.display.set_mode((width, height))
    position = [width // 2, height // 2]
    radius = 20
    trail = []
    angle = 90
    key_events = []

    image_orig = pygame.image.load("millos.png")
    image_orig = pygame.transform.scale(image_orig, (2 * radius, 2 * radius))
    rotated_image = pygame.transform.rotate(image_orig, angle)
    rotated_image = image_orig.copy()

    button_width = 200
    button_height = 50
    
    button_x = width - button_width - 10
    button_y = height - button_height - 10
    button_rect = pygame.Rect(button_x, button_y, button_width, button_height)
    font = pygame.font.Font(None, 36)
    text = font.render("Guardar", 1, (255, 255, 255))
    text_pos = text.get_rect(centerx=button_rect.centerx, centery=button_rect.centery)
    
    

        
    def take_screenshot():
        # Obtener la captura de pantalla
    	screenshot = pygame.surfarray.array3d(screen)
    	# Guardar la captura de pantalla en un archivo
    	im = Image.fromarray(screenshot).rotate(-90).transpose(Image.FLIP_LEFT_RIGHT)
    	im.save("screenshot.png")
    	save_file()
    
    running = True

    
    x,y=0,0
    l = -1
    pos = open('pos.txt','w')
    pos.write(f'{x},{y},{angle}')
    pos.close()
                  
    while running:
        with open('keys.txt', 'r') as f:
            try:
                registro = f.readlines()
                
                if len(registro)>l:
                    last_line = registro[-1][0]
                    l = len(registro)
                    pos_l = open('pos.txt','r')
                    pos_actual = pos_l.readline()
                    pos_l.close()
                    x,y,angle =cinematica_directa(1, 5, 10, last_line, float(pos_actual.split(',')[0]),float(pos_actual.split(',')[1]),float(pos_actual.split(',')[2]))
                    pos = open('pos.txt','w')
                    pos.write(str(x)+','+str(y)+','+str(angle))
                    pos.close()

                else:
                    last_line = '-1'
                    pos_l = open('pos.txt','r')
                    pos_actual = pos_l.readline()
                    pos_l.close()
                    
                    x,y = float(pos_actual.split(',')[0]),float(pos_actual.split(',')[1])
                
            except:
                    
                x,y = 0,0
                
        position = [width // 2 + x, height // 2 - y]

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        # Si se presiona el botón para tomar la captura de pantalla
            if event.type == pygame.MOUSEBUTTONDOWN:
            # Obtener la posición del cursor
                mouse_x, mouse_y = pygame.mouse.get_pos()
            # Verificar si el cursor está en la posición del botón
                # button_x, button_y, button_width, button_height
                if button_x < mouse_x < button_x + button_width and button_y < mouse_y < button_y + button_height:
                    take_screenshot()
                    

        #actualizacion al movimiento
        screen.fill((255, 255, 255))
        pygame.draw.rect(screen, (0, 0, 255), button_rect)
        screen.blit(text, text_pos)
        
        
        for pos in trail:
            pygame.draw.rect(screen, (0, 255, 0), (pos[0] - radius, pos[1] - radius, 2 * radius, 2 * radius))
        trail.append(position.copy())
        screen.blit(rotated_image, (position[0]-radius, position[1]-radius))
        pygame.display.update()


        
       



    pygame.quit()
    with open("key_events.txt", "w") as f:
        for key in key_events:
            f.write(f"{key}\n")

