import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Point
import Adafruit_PCA9685
import math
import time

class Brazo(Node):
    def __init__(self):
        super().__init__('brazo')
        self.pwm = Adafruit_PCA9685.PCA9685()
        self.pwm.set_pwm_freq(50)

        self.posicion_inicial()
        
         # Pedir las coordenadas x e y
        opcion = int(input('Introduce el número de la opción: '))
 
        if opcion == 3:
            # Pedir las coordenadas x e y
            x = float(input('Introduce la coordenada x: '))
            y = float(input('Introduce la coordenada y: '))
            
            # Calcular los valores de PWM y mover los servos
            pwm1, pwm2 = self.mover_a_punto(x, y)
            print(pwm1,pwm2)
            self.pwm.set_pwm(10, 0, int(pwm1))
            time.sleep(2)
            self.pwm.set_pwm(12, 0, int(pwm2))
        elif opcion == 4:
            self.funcion_4()  # Aquí llamas a la función 4 que definirás más adelante
        

    def funcion_4(self):
        self.mover_a_posicion_inicial()
        time.sleep(2)
        self.pwm.set_pwm(12, 0, 110)
        time.sleep(2)
        self.pwm.set_pwm(10, 0, 200)
        time.sleep(2)
        self.pwm.set_pwm(15, 0, 230)
        time.sleep(2)
        self.pwm.set_pwm(10, 0, 100)
        time.sleep(2)
        self.pwm.set_pwm(12, 0, 100)
        time.sleep(5)
        self.pwm.set_pwm(12, 0, 130)
        time.sleep(2)
        self.pwm.set_pwm(10, 0, 212)
        time.sleep(2)
        self.pwm.set_pwm(15, 0, 100)
        time.sleep(2)
        self.mover_a_posicion_inicial()
        
    def posicion_inicial(self):
        # Aquí pones los valores PWM que corresponden a la posición inicial
        pwm1_inicial = 100
        pwm2_inicial = 100
        self.pwm.set_pwm(10, 0, pwm1_inicial)
        time.sleep(2)
        self.pwm.set_pwm(12, 0, pwm2_inicial)
        
    def mover_a_posicion_inicial(self):
        self.pwm.set_pwm(15, 0, 100)
        time.sleep(2)
        self.pwm.set_pwm(10, 0, 100)
        time.sleep(2)
        self.pwm.set_pwm(12, 0, 100)    

    def mover_a_punto(self, x, y):
        L1 = 7
        L2 = 11

        angle1_initial = 35
        angle2_initial = 90

            # Distancia desde el origen hasta el punto objetivo
        dist = math.sqrt(x**2 + y**2)
        
        print('dist', dist)
        
        
        # Uso del teorema de los cosenos para calcular los ángulos
        angle1 = math.acos((L1**2 + dist**2 - L2**2) / (2*L1*dist))
        angle2 = math.acos((L1**2 + L2**2 - dist**2) / (2*L1*L2))
        print('a1  ', angle1)    
        print('a2   ' , angle2)
        # Conversión de los ángulos a grados
        angle1 = math.degrees(angle1) + angle1_initial
        angle2 = math.degrees(angle2) + angle2_initial
        print('a1.1', angle1)    
        print('a2.2', angle2)    
        # Escalando los valores de los ángulos a los valores de PWM
        pwm1 = ((angle1 - angle1_initial) / 90) * 200 + 100
        pwm2 = ((angle2 - angle2_initial) / 90) * 200 + 100

        return pwm1, pwm2


def main(args=None):
    rclpy.init(args=args)

    node = Brazo()

    rclpy.spin(node)


if __name__ == '__main__':
    main()
