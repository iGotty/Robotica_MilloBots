import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Point
import Adafruit_PCA9685
import math
import time

class Brazo(Node):
    def __init__(self):
        super().__init__('brazo')
        self.pwm = Adafruit_PCA9685.PCA9685()
        self.pwm.set_pwm_freq(50)

        
        
        # Pedir las coordenadas x e y
        x = float(input('Introduce la coordenada x: '))
        y = float(input('Introduce la coordenada y: '))


        # Establecer la posición inicial de los servos
        self.posicion_inicial()


        # Calcular los valores de PWM y mover los servos
        pwm1, pwm2 = self.mover_a_punto(x, y)

        self.pwm.set_pwm(10, 0, pwm1)
        time.sleep(2)
        self.pwm.set_pwm(12, 0, pwm2)
        

    def posicion_inicial(self):
        # Aquí pones los valores PWM que corresponden a la posición inicial
        pwm1_inicial = 100
        pwm2_inicial = 100
        self.pwm.set_pwm(10, 0, pwm1_inicial)
        time.sleep(2)
        self.pwm.set_pwm(12, 0, pwm2_inicial)
        

    def mover_a_punto(self, x, y):
        L1 = 7
        L2 = 11
        angle1_initial = 35
        angle2_initial = 90

        # Distancia desde el origen hasta el punto objetivo
        dist = math.sqrt(x**2 + y**2)    

        # Uso del teorema de los cosenos para calcular los ángulos
        angle1 = math.acos((L1**2 + dist**2 - L2**2) / (2*L1*dist))
        angle2 = math.acos((L1**2 + L2**2 - dist**2) / (2*L1*L2))

        # Convertir los ángulos a grados
        angle1 = math.degrees(angle1)
        angle2 = math.degrees(angle2)

        # Ajustar los ángulos a la configuración de los servos
        angle1 = angle1_initial - angle1
        angle2 = angle2_initial - angle2

        # Calcular los valores de PWM para cada servo
        pwm1 = int((angle1 / 90) * 200 + 100)
        pwm2 = int((angle2 / 90) * 200 + 100)

        return pwm1, pwm2


def main(args=None):
    rclpy.init(args=args)

    node = Brazo()

    rclpy.spin(node)


if __name__ == '__main__':
    main()
