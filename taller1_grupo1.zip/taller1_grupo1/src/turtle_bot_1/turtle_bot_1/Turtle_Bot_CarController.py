import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from std_msgs.msg import String
import RPi.GPIO as GPIO

class CarController(Node):

    def __init__(self):
        super().__init__('car_controller')
        
        self.Motor1A = 23
        self.Motor1B = 24
        self.Motor2A = 6
        self.Motor2B = 5
        self.EN1 = 18
        self.EN2 = 19
        self.setup_motors()

        self.cmd_vel_pub = self.create_publisher(Twist, '/robot_cmdVel', 10)

        self.key_sub = self.create_subscription(String, '/key_pressed', self.key_callback, 10)

        self.angular_vel = float(input("Ingrese la velocidad angular a la que quiere que el robot se mueva (0 a 1): "))
        self.lineal_vel = float(input("Ingrese la velocidad lineal a la que quiere que el robot se mueva (0 a 1): "))

    
    def setup_motors(self):
        GPIO.setmode(GPIO.BCM)
        GPIO.setwarnings(False)

        GPIO.setup(self.Motor1A, GPIO.OUT)
        GPIO.setup(self.Motor1B, GPIO.OUT)
        GPIO.setup(self.Motor2A, GPIO.OUT)
        GPIO.setup(self.Motor2B, GPIO.OUT)
        GPIO.setup(self.EN1, GPIO.OUT)
        GPIO.setup(self.EN2, GPIO.OUT)

        self.pwm_motor1 = GPIO.PWM(self.EN1, 100)
        self.pwm_motor2 = GPIO.PWM(self.EN2, 100)

        self.pwm_motor1.start(0)
        self.pwm_motor2.start(0)

    def adelante(self):
        print("El robot se esta moviendo adelante")
        self.pwm_motor1.ChangeDutyCycle(self.lineal_vel * 100)
        self.pwm_motor2.ChangeDutyCycle(self.lineal_vel * 100)
        GPIO.output(self.Motor1A,GPIO.LOW)
        GPIO.output(self.Motor1B,GPIO.HIGH)

        GPIO.output(self.Motor2A,GPIO.LOW)
        GPIO.output(self.Motor2B,GPIO.HIGH)
        
        

        # Publicar la velocidad actual en el tópico /robot_cmdVel
        cmd_vel_msg = Twist()
        cmd_vel_msg.linear.x = self.lineal_vel
        cmd_vel_msg.angular.z = 0.0
        self.cmd_vel_pub.publish(cmd_vel_msg)
    def atras(self):
        print("El robot se esta moviendo para atras")
        self.pwm_motor1.ChangeDutyCycle(self.lineal_vel * 100)
        self.pwm_motor2.ChangeDutyCycle(self.lineal_vel * 100)
        GPIO.output(self.Motor1A,GPIO.HIGH)
        GPIO.output(self.Motor1B,GPIO.LOW)

        GPIO.output(self.Motor2A,GPIO.HIGH)
        GPIO.output(self.Motor2B,GPIO.LOW)

        # Publicar la velocidad actual en el tópico /robot_cmdVel
        cmd_vel_msg = Twist()
        cmd_vel_msg.linear.x = -self.lineal_vel
        cmd_vel_msg.angular.z = 0.0
        self.cmd_vel_pub.publish(cmd_vel_msg)

    def girar_izquierda(self):
        print("El robot esta girando a la izquierda")
        self.pwm_motor1.ChangeDutyCycle(self.angular_vel * 100)
        self.pwm_motor2.ChangeDutyCycle(self.angular_vel * 100)
        GPIO.output(self.Motor1A,GPIO.HIGH)
        GPIO.output(self.Motor1B,GPIO.HIGH)

        GPIO.output(self.Motor2A,GPIO.LOW)
        GPIO.output(self.Motor2B,GPIO.HIGH)

        # Publicar la velocidad actual en el tópico /robot_cmdVel
        cmd_vel_msg = Twist()
        cmd_vel_msg.linear.x = 0.0
        cmd_vel_msg.angular.z = self.angular_vel
        self.cmd_vel_pub.publish(cmd_vel_msg)

    def girar_derecha(self):
        print("El robot esta girando a la derecha")
        self.pwm_motor1.ChangeDutyCycle(self.angular_vel * 100)
        self.pwm_motor2.ChangeDutyCycle(self.angular_vel * 100)
        GPIO.output(self.Motor1A,GPIO.LOW)
        GPIO.output(self.Motor1B,GPIO.HIGH)

        GPIO.output(self.Motor2A,GPIO.HIGH)
        GPIO.output(self.Motor2B,GPIO.HIGH)

        # Publicar la velocidad actual en el tópico /robot_cmdVel
        cmd_vel_msg = Twist()
        cmd_vel_msg.linear.x = 0.0
        cmd_vel_msg.angular.z = -self.angular_vel
        self.cmd_vel_pub.publish(cmd_vel_msg)

    def stop_motors(self):
        print("El robot se detiene")
        self.pwm_motor1.ChangeDutyCycle(0)
        self.pwm_motor2.ChangeDutyCycle(0)
        GPIO.output(self.Motor1B, GPIO.LOW)
        GPIO.output(self.Motor2B, GPIO.LOW)

        # Publicar la velocidad actual en el tópico /robot_cmdVel
        cmd_vel_msg = Twist()
        cmd_vel_msg.linear.x = 0.0
        cmd_vel_msg.angular.z = 0.0
        self.cmd_vel_pub.publish(cmd_vel_msg)

    def key_callback(self, msg):
        key = msg.data
        if key == 'w':
            self.adelante()
        elif key == 's':
            self.atras()
        elif key == 'q':
            self.girar_izquierda()
        elif key == 'e':
            self.girar_derecha()
        else:
            self.stop_motors()

def main(args=None):
    rclpy.init(args=args)

    car_controller = CarController()

    rclpy.spin(car_controller)

if __name__ == '__main__':
    print("CarController node initialized")
    main()
