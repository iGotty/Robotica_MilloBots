import imageio
import networkx as nx
import numpy as np
import matplotlib.pyplot as plt
import heapq
import math
from skimage.morphology import square, binary_erosion, binary_opening
from PIL import Image as im
import cv2


def load_pgm_map(filename):
    image = imageio.imread(filename)
    binary = np.zeros_like(image)
    binary[image > 94] = 255
    # La imagen se carga como una matriz numpy, donde los valores representan los niveles de gris
    return binary


def erode_map(map_img):
    struct = square(64)
    eroded_map = binary_erosion(map_img, struct)
    # eroded_map = im.fromarray(eroded_map)
    return eroded_map


def calculate_shortest_path(map_data, start, goal):
    # Dimensiones del mapa
    height, width = map_data.shape

    # Direcciones posibles: arriba, abajo, izquierda, derecha
    directions = [(0, -1), (0, 1), (-1, 0), (1, 0)]

    # Costo estimado desde el inicio hasta cada celda (inicialmente infinito)
    cost_so_far = np.full((height, width), math.inf)
    cost_so_far[start] = 0

    # Frontera para explorar celdas (prioridad basada en el costo estimado total)
    frontier = []
    heapq.heappush(frontier, (0, start))

    # Mapa de padres para reconstruir la ruta final
    parent_map = {}

    while frontier:
        _, current = heapq.heappop(frontier)

        if current == goal:
            break

        for dx, dy in directions:
            next_x, next_y = current[0] + dx, current[1] + dy

            if 0 <= next_x < height and 0 <= next_y < width and map_data[next_x, next_y] != 0:
                new_cost = cost_so_far[current] + 1

                if new_cost < cost_so_far[next_x, next_y]:
                    cost_so_far[next_x, next_y] = new_cost
                    priority = new_cost + heuristic(goal, (next_x, next_y))
                    heapq.heappush(frontier, (priority, (next_x, next_y)))
                    parent_map[(next_x, next_y)] = current

    # Reconstruir la ruta desde el punto de inicio hasta el destino
    path = []
    current = goal
    while current != start:
        path.append(current)
        current = parent_map[current]
    path.append(start)
    path.reverse()

    return path


def heuristic(a, b):
    # Distancia de Manhattan como heurística
    return abs(a[0] - b[0]) + abs(a[1] - b[1])


def mark_path_on_map(map_data, path):
    marked_map = np.copy(map_data)
    rgb_marked_map = np.zeros((marked_map.shape[0], marked_map.shape[1], 3))

    for i in range(3):
        rgb_marked_map[:, :, i] = marked_map

    for i in range(len(path) - 1):
        cv2.line(rgb_marked_map, path[i][::-1], path[i + 1][::-1], (255, 0, 0), thickness=20)

    return rgb_marked_map


def save_pgm_map(filename, map_data):
    imageio.imsave(filename, map_data)


def display_map(map_data):
    plt.imshow(map_data, cmap='gray')
    plt.axis('off')
    plt.show()


map_data = load_pgm_map('RoboticaFinal.pgm')
#display_map(map_data)
map_data = erode_map(map_data)

# Interacción con el usuario para seleccionar el punto inicial
print("Haz clic en el mapa para seleccionar el punto inicial.")
fig, ax = plt.subplots()
ax.imshow(map_data, cmap='gray')
plt.axis('off')
point = plt.ginput(1, timeout=-1)[0]
start = (int(point[1]), int(point[0]))
print('Comienzooooo:', start)
plt.close(fig)

goal = (900, 1600)

path = calculate_shortest_path(map_data, start, goal)
marked_map = mark_path_on_map(map_data, path)
save_pgm_map('mapa_con_ruta.pgm', marked_map)
display_map(marked_map)
