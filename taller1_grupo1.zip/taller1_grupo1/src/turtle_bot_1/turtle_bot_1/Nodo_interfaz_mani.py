import rclpy
from rclpy.node import Node

from manipulador_interfaz import mani_interfaz


class ManiNode(Node):
    def __init__(self):
        super().__init__('mani_node')

    def run_mani_interfaz(self):
        self.get_logger().info('Ejecutando mani_interfaz()')
        mani_interfaz()


def main(args=None):
    rclpy.init(args=args)
    mani_node = ManiNode()
    mani_node.run_mani_interfaz()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
