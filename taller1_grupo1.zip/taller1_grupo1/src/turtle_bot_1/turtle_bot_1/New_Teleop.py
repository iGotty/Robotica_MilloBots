
from pyfiglet import Figlet
import time
import RPi.GPIO as GPIO

class Turtle_Bot_Teleop(Node):

    def __init__(self):
        super().__init__('turle_bot_teleop')
        
        self.Motor_A_EN    = 4  
        self.Motor_A_Pin1  = 26  
        self.Motor_A_Pin2  = 21  
        #self.setup_motors()

        # Crear el publicador para el tópico /robot_cmdVel
        self.cmd_vel_pub = self.create_publisher(Twist, '/robot_cmdVel', 10)

        # Print cool
        self.fuente = Figlet(font="graffiti")
        print(self.fuente.renderText("Bienvenido!"))
        


    def setup():#Motor initialization  
        global pwm_A  
        GPIO.setwarnings(False)  
        GPIO.setmode(GPIO.BCM)  
        GPIO.setup(Motor_A_EN, GPIO.OUT)  
        GPIO.setup(Motor_A_Pin1, GPIO.OUT)  
        GPIO.setup(Motor_A_Pin2, GPIO.OUT)  
        motorStop()  
        try:  
            pwm_A = GPIO.PWM(Motor_A_EN, 1000)  
        except:  
            pass  

    def destroy():  
        motorStop()  
        GPIO.cleanup()  

    def move(speed, direction, turn, radius=0.6):   # 0 < radius <= 1    
    #speed = 100  
        if direction == 'forward':  
            if turn == 'right':  
                motor_left(0, left_backward, int(speed*radius))  
                motor_right(1, right_forward, speed)  
            elif turn == 'left':  
                motor_left(1, left_forward, speed)  
                motor_right(0, right_backward, int(speed*radius))  
            else:  
                motor_left(1, left_forward, speed)  
                motor_right(1, right_forward, speed)  
        else:  
            pass  

'''    def on_press(self,key):
        try:
            #Todo: asignar las teclas respectivas a una orden que permita al robot realizar una accion
            print('Buena Bro! Estas oprimiendo la tecla {0}'.format(
                key.char))
            if key.char=='w':
                self.adelante()
            if key.char=='s':
                self.atras()
            if key.char=='e':
                self.girar_derecha()
            if key.char=='q':
                self.girar_izquierda()
        except AttributeError:
            print('A que juegas brother? Deja de oprimir teclas raras, oprimiste la tecla {0}'.format(
                key))
    def on_release(self,key):
        print('Que lastimaa bro, dejaste de oprimir la tecla {0} '.format(
            key))
        try:
            if key.char=='w' or key.char=='s' or key.char=='e' or key.char=='q':
                self.stop_motors()
                
            if key == keyboard.Key.esc:
                # Stop listener
                return False
        except AttributeError:
            print('Que lastimaa bro, dejaste de oprimir la tecla {0} '.format(
            key))'''
	
    # (Resto del código)
def main(args=None):
    rclpy.init(args=args)

    turle_bot_teleop = Turtle_Bot_Teleop()

    rclpy.spin(turle_bot_teleop)
    
if __name__ == '__main__':
    try:  
        speed_set = 60  
        setup()  
        move(speed_set, 'forward', 'no', 0.8)  
        time.sleep(1.3)  
        motorStop()  
        destroy()  
    except KeyboardInterrupt:  
        destroy()  
