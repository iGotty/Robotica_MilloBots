import rclpy
from rclpy.node import Node

import interfaz

class MyNode(Node):
    def __init__(self):
        super().__init__('Turtle_Bot_1_interface')
        # Configura tu nodo
        self.create_timer(1.0, self.timer_callback)
        
    
    def timer_callback(self):
        interfaz.run_interface()

def main(args=None):
    rclpy.init(args=args)

    node = MyNode()

    rclpy.spin(node)

    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
