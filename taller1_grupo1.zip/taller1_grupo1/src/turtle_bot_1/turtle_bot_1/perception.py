import cv2
import easyocr
import matplotlib.pyplot as plt
import numpy as np
from skimage.io import imshow

def figure_detection(image, show=False):
    image = image[200:700,300:800,:]

    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    canny = cv2.Canny(gray, 10, 150)
    elipce = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 1))
    cruz = cv2.getStructuringElement(cv2.MORPH_CROSS, (1, 1))
    canny = cv2.dilate(canny, cruz, iterations=2)
    canny = cv2.erode(canny, elipce, iterations=3)
    canny = cv2.dilate(canny, cruz, iterations=2)
    cruz = cv2.getStructuringElement(cv2.MORPH_CROSS, (1, 1))
    canny = cv2.erode(canny, cruz, iterations=1)
    canny = cv2.dilate(canny, elipce, iterations=2)

    cnts,_ = cv2.findContours(canny, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    figura = "-1"
    fonts = 10

    for c in cnts:
        epsilon = 0.01*cv2.arcLength(c,True)
        approx = cv2.approxPolyDP(c,epsilon,True)
        area = cv2.contourArea(approx)

        if area < 1000:
            continue

        x,y,w,h = cv2.boundingRect(approx)

        if len(approx)==3:
            figura = 'Figura de 3 lados'

            
        if len(approx)==4:
            figura = 'Figura de 4 lados'

            
        if len(approx)==5:
            figura = 'Figura de 5 lados'

            
        if len(approx)==6:
            figura = 'Figura de 6 lados'

            
        if len(approx)>6:
            figura = 'Figura de infinitos lados'
            
        plt.text(w, h-200, figura, fontsize=8, color='white')
        rect = plt.Rectangle((w, h-250), 420, 75, facecolor=(166/255, 56/255, 242/255), edgecolor=(166/255, 56/255, 242/255))
        cv2.drawContours(image, [approx], 0, (166, 56, 242),2)
        plt.gca().add_patch(rect)

    if show:

        canny = cv2.cvtColor(canny, cv2.COLOR_BGR2RGB)
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        plt.subplot(1, 2, 1)
        plt.imshow(canny)
        plt.axis('off')
        plt.subplot(1, 2, 2)
        plt.imshow(image)
        plt.axis('off')
        plt.show()

    return figura


def text_detection(image, show=False):
    reader = easyocr.Reader(["es"], gpu=False)
    result = reader.readtext(image, paragraph=False)
    image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    text = "-1"
    for res in result:
        
        if res[-1] < 0.95 or len(res[1]) < 2:
            continue

        text = res[1]
        pt0 = res[0][0]
        pt1 = res[0][1]
        pt2 = res[0][2]
        pt3 = res[0][3]
        rect = plt.Rectangle((pt0[0], pt0[1]), pt1[0] - pt0[0], pt1[1] - pt0[1]-40, facecolor=(166/255, 56/255, 242/255), edgecolor=(166/255, 56/255, 242/255))
        plt.gca().add_patch(rect)
        plt.text(pt0[0], pt0[1] - 3, res[1], fontsize=8, color='white')
        rect = plt.Rectangle((pt0[0], pt0[1]), pt2[0] - pt0[0], pt2[1] - pt0[1], edgecolor=(166/255, 56/255, 242/255), fill=False)
        plt.gca().add_patch(rect)

    if show:
        plt.imshow(image)
        plt.axis('off')
        plt.show()

    return text 


def color_detection(image):
    w,h = 900, 1200
    image = image[w:h,:,:]


    
    frameHSV = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)

    redBajo1 = np.array([0, 100, 20], np.uint8)
    redAlto1 = np.array([8, 255, 255], np.uint8)
    redBajo2=np.array([175, 100, 20], np.uint8)
    redAlto2=np.array([179, 255, 255], np.uint8)

    yellowBajo=np.array([15, 100, 20], np.uint8)
    yellowAlto=np.array([30, 255, 255], np.uint8)

    greenBajo=np.array([31, 100, 20], np.uint8)
    greenAlto=np.array([80, 255, 255], np.uint8)

    blueBajo=np.array([85, 100, 20], np.uint8)
    blueAlto=np.array([120, 255, 255], np.uint8)

    purpleBajo=np.array([130, 100, 20], np.uint8)
    purpleAlto=np.array([140, 255, 255], np.uint8)

    pinkBajo=np.array([145, 100, 20], np.uint8)
    pinkAlto=np.array([170, 255, 255], np.uint8)


    maskRed1 = cv2.inRange(frameHSV, redBajo1, redAlto1)
    maskRed2 = cv2.inRange(frameHSV, redBajo2, redAlto2)

    maskred = cv2.add(maskRed1, maskRed2), "Rojo"
    maskyellow = cv2.inRange(frameHSV, yellowBajo, yellowAlto), "Amarillo"
    maskgreen = cv2.inRange(frameHSV, greenBajo, greenAlto), "Verde"
    maskblue = cv2.inRange(frameHSV, blueBajo, blueAlto), "Azul"
    maskpurple = cv2.inRange(frameHSV, purpleBajo, purpleAlto), "Morado"
    maskpink = cv2.inRange(frameHSV, pinkBajo, pinkAlto), "Rosado"

    mayor = 0, "-1"
    for mask in [maskred, maskyellow, maskpurple, maskpink, maskgreen, maskblue]:
        if np.sum(mask[0]) > mayor[0]:
            mayor = np.sum(mask[0]), mask[1] 

    plt.text(w-150, h, mayor[1], fontsize=8, color='white')
    rect = plt.Rectangle((w-150, h-50), 170, 75, facecolor=(166/255, 56/255, 242/255), edgecolor=(166/255, 56/255, 242/255))
    plt.gca().add_patch(rect)
    return mayor[1]
    
def f_per(image, show=False, fps=10):
    print("Analisis de texto")
    text = text_detection(image)
    print("Analisis de figura")
    figura = figure_detection(image)
    print("Analisis de color")
    color = color_detection(image)
    print((figura, text, color))
    fig, ax = plt.subplots()
    c = 0
    if show:
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        imshow(image, ax = ax)
        plt.axis('off')
        plt.pause(1 / fps)
        ax.cla()
        if c%3 == 0:
            plt.close(fig)

                
    return (figura+","+text+","+color)

