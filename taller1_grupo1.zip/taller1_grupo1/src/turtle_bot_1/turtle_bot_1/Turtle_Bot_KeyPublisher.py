import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from pynput import keyboard
from pyfiglet import Figlet
import time

class KeyPublisher(Node):

    def __init__(self):
        super().__init__('key_publisher')
        
        self.key_pub = self.create_publisher(String, '/key_pressed', 10)

        # Print cool
        self.fuente = Figlet(font="graffiti")
        print(self.fuente.renderText("Bienvenido!"))
        print(self.fuente.renderText("Hincha de millos!\n"))








        # Inicializar el listener del teclado
        listener = keyboard.Listener(
            on_press=self.on_press,
            on_release=self.on_release)
        listener.start()

    def on_press(self,key):
        try:
            # Publicar la tecla presionada
            print('Buena Bro! Estas oprimiendo la tecla {0}'.format(
                key.char))
            key_msg = String()
            key_msg.data = key.char
            self.key_pub.publish(key_msg)
        except AttributeError:
            print('A que juegas brother? Deja de oprimir teclas raras, oprimiste la tecla {0}'.format(
                key))

    def on_release(self,key):
        

        key_msg = String()
        key_msg.data = "h"
        self.key_pub.publish(key_msg)


        try:


            if key == keyboard.Key.esc:
                # Stop listener
                return False

        except AttributeError:
            print('Que lastima bro, dejaste de oprimir la tecla {0} '.format(
            key))
        
def main(args=None):
    rclpy.init(args=args)

    key_publisher = KeyPublisher()

    rclpy.spin(key_publisher)

if __name__ == '__main__':
    print("KeyPublisher node initialized")
    main()