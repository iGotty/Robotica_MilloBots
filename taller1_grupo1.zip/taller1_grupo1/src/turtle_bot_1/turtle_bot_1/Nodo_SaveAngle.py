import rclpy
from rclpy.node import Node
from std_msgs.msg import String

class AngulosSubscriber(Node):
    def __init__(self):
        super().__init__('angulos_subscriber')
        self.subscription = self.create_subscription(
            String,
            '/angulos',
            self.angulos_callback,
            10
        )
        self.subscription  # Evitar que el objeto sea destruido prematuramente
        self.archivo = 'mani.txt'

    def angulos_callback(self, msg):
        angulos = msg.data

        with open(self.archivo, 'a') as file:
            self.get_logger().info('Angulos recibidos: %s' % angulos)
            file.write(angulos + '\n')

def main(args=None):
    rclpy.init(args=args)
    angulos_subscriber = AngulosSubscriber()
    rclpy.spin(angulos_subscriber)
    angulos_subscriber.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
