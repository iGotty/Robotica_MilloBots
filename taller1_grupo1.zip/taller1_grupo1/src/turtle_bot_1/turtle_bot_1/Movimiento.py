import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from std_msgs.msg import String
import time
import RPi.GPIO as GPIO
import Adafruit_PCA9685

class Movimiento(Node):

    def __init__(self):
        super().__init__('movimiento')
        self.pwm = Adafruit_PCA9685.PCA9685()
        self.pwm.set_pwm_freq(50)
        self.Motor_A_EN    = 4
        self.Motor_B_EN    = 17

        self.Motor_A_Pin1  = 14
        self.Motor_A_Pin2  = 15
        self.Motor_B_Pin1  = 27
        self.Motor_B_Pin2  = 18
        self.INCREMENT = 5
        self.DELAY = 0.1
        
        self.angulo13=35
        self.angulo12=55
        self.pos_servo12 = 100
        self.pos_servo13 = 100
        self.pos_servo15 = 100
        self.Dir_forward   = 0
        self.Dir_backward  = 1

        self.left_forward  = 0
        self.left_backward = 1

        self.right_forward = 0
        self.right_backward= 1

        self.pwn_A = 0
        self.pwm_B = 0
        self.setup_motors()
        self.contador=2
        self.angulos_pub = self.create_publisher(String, '/angulos', 10)

        self.key_sub = self.create_subscription(String, '/key_pressed', self.key_callback, 10)
        angulo_msg=String()
        angulo_msg.data="40,55"
        self.angulos_pub.publish(angulo_msg)

        # Define some constants
        self.INCREMENT = 10
        self.DELAY = 0.1
	
        # Initial positions
        self.pos_servo12 = 100
        self.pos_servo13 = 100
        self.pos_servo15 = 100 

    def motorStop(self):#Motor stops
        GPIO.output(self.Motor_A_Pin1, GPIO.LOW)
        GPIO.output(self.Motor_A_Pin2, GPIO.LOW)
        GPIO.output(self.Motor_B_Pin1, GPIO.LOW)
        GPIO.output(self.Motor_B_Pin2, GPIO.LOW)
        GPIO.output(self.Motor_A_EN, GPIO.LOW)
        GPIO.output(self.Motor_B_EN, GPIO.LOW)
    
    def setup_motors(self):
        global pwm_A, pwm_B
        GPIO.setwarnings(False)
        GPIO.setmode(GPIO.BCM)
        GPIO.setup(self.Motor_A_EN, GPIO.OUT)
        GPIO.setup(self.Motor_B_EN, GPIO.OUT)
        GPIO.setup(self.Motor_A_Pin1, GPIO.OUT)
        GPIO.setup(self.Motor_A_Pin2, GPIO.OUT)
        GPIO.setup(self.Motor_B_Pin1, GPIO.OUT)
        GPIO.setup(self.Motor_B_Pin2, GPIO.OUT)

        self.motorStop()
        try:
            pwm_A = GPIO.PWM(self.Motor_A_EN, 1000)
            pwm_B = GPIO.PWM(self.Motor_B_EN, 1000)
        except:
            pass
    
    def motor_left(self,status, direction, speed):#Motor 2 positive and negative rotation
        if status == 0: # stop
            GPIO.output(self.Motor_B_Pin1, GPIO.LOW)
            GPIO.output(self.Motor_B_Pin2, GPIO.LOW)
            GPIO.output(self.Motor_B_EN, GPIO.LOW)
        else:
            if direction == self.Dir_backward:
                GPIO.output(self.Motor_B_Pin1, GPIO.HIGH)
                GPIO.output(self.Motor_B_Pin2, GPIO.LOW)
                pwm_B.start(100)
                pwm_B.ChangeDutyCycle(speed)
            elif direction == self.Dir_forward:
                GPIO.output(self.Motor_B_Pin1, GPIO.LOW)
                GPIO.output(self.Motor_B_Pin2, GPIO.HIGH)
                pwm_B.start(0)
                pwm_B.ChangeDutyCycle(speed)


    def motor_right(self,status, direction, speed):#Motor 1 positive and negative rotation
        if status == 0: # stop
            GPIO.output(self.Motor_A_Pin1, GPIO.LOW)
            GPIO.output(self.Motor_A_Pin2, GPIO.LOW)
            GPIO.output(self.Motor_A_EN, GPIO.LOW)
        else:
            if direction == self.Dir_forward:#
                GPIO.output(self.Motor_A_Pin1, GPIO.HIGH)
                GPIO.output(self.Motor_A_Pin2, GPIO.LOW)
                pwm_A.start(100)
                pwm_A.ChangeDutyCycle(speed)
            elif direction == self.Dir_backward:
                GPIO.output(self.Motor_A_Pin1, GPIO.LOW)
                GPIO.output(self.Motor_A_Pin2, GPIO.HIGH)
                pwm_A.start(0)
                pwm_A.ChangeDutyCycle(speed)
        return direction


    def move(self,speed, direction, turn, radius=0.6):   # 0 < radius <= 1  
        
        #speed = 100
        if direction == 'forward':
            if turn == 'right':
                self.motor_left(0, self.left_backward, int(speed*radius))
                self.motor_right(1, self.right_forward, speed)
            elif turn == 'left':
                self.motor_left(1, self.left_forward, speed)
                self.motor_right(0, self.right_backward, int(speed*radius))
            else:
                self.motor_left(1, self.left_forward, speed)
                self.motor_right(1, self.right_forward, speed)
        elif direction == 'backward':
            if turn == 'right':
                self.motor_left(0, self.left_forward, int(speed*radius))
                self.motor_right(1, self.right_backward, speed)
            elif turn == 'left':
                self.motor_left(1, self.left_backward, speed)
                self.motor_right(0, self.right_forward, int(speed*radius))
            else:
                self.motor_left(1, self.left_backward, speed)
                self.motor_right(1, self.right_backward, speed)
        elif direction == 'no':
            if turn == 'right':
                self.motor_left(1, self.left_backward, speed)
                self.motor_right(1, self.right_forward, speed)
            elif turn == 'left':
                self.motor_left(1, self.left_forward, speed)
                self.motor_right(1, self.right_backward, speed)
            else:
                self.motorStop()
        else:
            pass
            
    def garra(self,accion):
        # Define some constants
        angulo_msg=String()
        
        if accion == 'abrir_garra':  # Si se presiona 'a', incrementa el valor para el servo 15.
            print('abrir_garra')
            self.pos_servo15 += self.INCREMENT
            print('hol1')
            print(self.pos_servo15)
            self.pos_servo15 = min(self.pos_servo15, 220)  # Limita el valor máximo a 510.
            self.pwm.set_pwm(15, 0, self.pos_servo15)
            print('hola2')
            time.sleep(self.DELAY)
        elif accion == 'cerrar_garra':  # Si se presiona 's', decrementa el valor para el servo 15.
            print('cerrar_garra')
            self.pos_servo15 -= self.INCREMENT
            print(self.pos_servo15)
            self.pos_servo15 = max(self.pos_servo15, 100)  # Limita el valor mínimo a 100.
            self.pwm.set_pwm(15, 0, self.pos_servo15)
            print('hola')
            time.sleep(self.DELAY)
        elif accion == 'abrir_13':  # Si se presiona 'd', incrementa el valor para el servo 13.
            print('abrir13')
            self.pos_servo13 += self.INCREMENT
            print(self.pos_servo13)
            self.pos_servo13 = min(self.pos_servo13, 300)
            self.angulo13=40+(self.pos_servo13-100)/(200/90)
            angulo_msg.data=str(self.angulo13)+","+str(self.angulo12)
            self.angulos_pub.publish(angulo_msg)
            self.pwm.set_pwm(10, 0, self.pos_servo13)
            time.sleep(self.DELAY)
        elif accion == 'cerrar_13':  # Si se presiona 'z', decrementa el valor para el servo 13.
            print('cerrar13')
            self.pos_servo13 -= self.INCREMENT
            print(self.pos_servo13)
            self.pos_servo13 = max(self.pos_servo13, 100)
            self.angulo13=40+(self.pos_servo13-100)/(200/90)
            angulo_msg.data=str(self.angulo13)+","+str(self.angulo12)
            self.angulos_pub.publish(angulo_msg)
            self.pwm.set_pwm(10, 0, self.pos_servo13)
            time.sleep(self.DELAY)
        elif accion == 'abrir_12':  # Si se presiona 'x', incrementa el valor para el servo 12.
            print('abrir12')
            self.pos_servo12 += self.INCREMENT
            self.pos_servo12 = min(self.pos_servo12, 300)
            print(self.pos_servo12)
            self.angulo12=55+(self.pos_servo12-100)/(200/90)
            angulo_msg.data=str(self.angulo13)+","+str(self.angulo12)
            self.angulos_pub.publish(angulo_msg)
            self.pwm.set_pwm(12, 0, self.pos_servo12)
            time.sleep(self.DELAY)
        elif accion == 'cerrar_12':  # Si se presiona 'c', decrementa el valor para el servo 12.
            print('cerrar12')
            print(self.INCREMENT)
            self.pos_servo12 -= self.INCREMENT
            print(self.pos_servo12)
            self.angulo12=55+(self.pos_servo12-100)/(200/90)
            angulo_msg.data=str(self.angulo13)+","+str(self.angulo12)
            self.angulos_pub.publish(angulo_msg)
            self.pos_servo12 = max(self.pos_servo12, 100)
            self.pwm.set_pwm(12, 0, self.pos_servo12)
            time.sleep(self.DELAY)
    
    


    def key_callback(self, msg):
        key = msg.data
        
        if key == 'w' :
            self.move(80,"forward","no",0.8)
        elif key == 's' :
            self.move(80,"backward","no",0.8)
        elif key == 'q' :
            self.move(80,"forward","left",0.8)
        elif key == 'e' :
            self.move(80,"forward","right",0.8)
        elif key == 'o':
            self.garra('abrir_garra')
        elif key == 'l':
            self.garra('cerrar_garra')
        elif key == 'i':
            self.garra('abrir_13')
        elif key == 'k':
            self.garra('cerrar_13')
        elif key == 'u':
            self.garra('abrir_12')
        elif key == 'j':
            print(key)
            self.garra('cerrar_12')
        else:
            self.motorStop()


    def destroy(self):
        self.motorStop()
        GPIO.cleanup()

def main(args=None):
    rclpy.init(args=args)

    movimiento = Movimiento()

    rclpy.spin(movimiento)

if __name__ == '__main__':
    print("Movimiento node initialized")
    main()
