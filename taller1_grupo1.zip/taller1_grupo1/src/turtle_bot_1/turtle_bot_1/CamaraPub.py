import rclpy
from rclpy.node import Node
import cv2
from cv_bridge import CvBridge
from sensor_msgs.msg import Image

class ImagePublisher(Node):

    def __init__(self):
        super().__init__('image_publisher')
        self.publisher_ = self.create_publisher(Image, '/image_raw', 10)
        self.timer = self.create_timer(0.5, self.publish_image)  
        self.bridge = CvBridge()

        # Aquí tendrías la URL proporcionada por la aplicación IP Webcam.
        # Normalmente, sería algo como 'http://<tu_ip>:8080/video'.
        self.cap = cv2.VideoCapture('http://192.168.71.161:8080/video')

    def publish_image(self):
        ret, frame = self.cap.read()
        if ret:
            msg = self.bridge.cv2_to_imgmsg(frame, 'bgr8')
            self.publisher_.publish(msg)
            self.get_logger().info('Successfully published image message')
        else:
            self.get_logger().info('Failed to read camera frame')

def main(args=None):
    rclpy.init(args=args)
    image_publisher = ImagePublisher()
    rclpy.spin(image_publisher)

    image_publisher.cap.release()
    image_publisher.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
