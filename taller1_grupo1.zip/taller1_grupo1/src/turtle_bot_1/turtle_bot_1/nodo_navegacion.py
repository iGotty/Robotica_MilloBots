import rclpy
from rclpy.node import Node
from path_planning import nav
from std_msgs.msg import String

class Navegacion(Node):
    def __init__(self):
        super().__init__('navegacion')
        self.map_data = None  # Aquí deberías cargar tus datos del mapa
        self.subscription = self.create_subscription(
            String,
            '/nav_goal',
            self.goal_callback,
            10
        )
        self.subscription

    def goal_callback(self, msg):
        # Manejar el mensaje recibido del tópico "/nav_goal"
        self.goal = msg.data
        self.run()

    def run(self):
        # Aquí deberías cargar tus datos del mapa, punto de inicio y punto de destino
        shortest_path = nav(self, self.goal)
        self.get_logger().info('El camino más corto es: %s' % shortest_path)

def main(args=None):
    rclpy.init(args=args)

    navegacion = Navegacion()

    try:
        navegacion.run()
        navegacion.get_logger().info('Navegando ... ')
    except Exception as e:
        navegacion.get_logger().error('Error en la navegación: %s' % str(e))
    finally:
        navegacion.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
