# Copyright 2016 Open Source Robotics Foundation, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
from services_package.srv import MoveRobot

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from std_msgs.msg import String
import time
import RPi.GPIO as GPIO


class TurtleBotPlayer(Node):

    def __init__(self):
        super().__init__('turtle_bot_player')
        #self.cmd_velPublisher = self.create_publisher(Twist, '/turtlebot_cmdVel', 10)
        #self.subscription_ = self.create_subscription(Twist,'turtlebot_position',self.listener_callback, 10)
        
        self.Motor1A = 23
        self.Motor1B = 24
        self.Motor2A = 6
        self.Motor2B = 5
        self.EN1 = 18
        self.EN2 = 19
        self.setup_motors()

        # Crear el publicador para el tópico /robot_cmdVel
        self.cmd_vel_pub = self.create_publisher(Twist, '/robot_cmdVel', 10)
        self.srv = self.create_service(MoveRobot, 'move_robot', self.move_robot_callback)

        '''self.vel = Twist()
        self.vel.linear.x = 0.0
        self.vel.linear.y = 0.0
        self.vel.linear.z = 0.0
        self.vel.angular.x = 0.0
        self.vel.angular.y = 0.0
        self.vel.angular.z = 0.0'''
        print('hola')
        
        with open('funciona_porfavor.txt', 'w') as f:
            f.write('funcionaaa')


    def setup_motors(self):
        GPIO.setmode(GPIO.BCM)
        GPIO.setwarnings(False)

        GPIO.setup(self.Motor1A, GPIO.OUT)
        GPIO.setup(self.Motor1B, GPIO.OUT)
        GPIO.setup(self.Motor2A, GPIO.OUT)
        GPIO.setup(self.Motor2B, GPIO.OUT)
        GPIO.setup(self.EN1, GPIO.OUT)
        GPIO.setup(self.EN2, GPIO.OUT)

        self.pwm_motor1 = GPIO.PWM(self.EN1, 100)
        self.pwm_motor2 = GPIO.PWM(self.EN2, 100)

        self.pwm_motor1.start(0)
        self.pwm_motor2.start(0)
    

    def adelante(self):
        print("El robot se esta moviendo adelante")

        self.pwm_motor1.ChangeDutyCycle(self.lineal_vel * 100)
        self.pwm_motor2.ChangeDutyCycle(self.lineal_vel * 100)

        GPIO.output(self.Motor1A,GPIO.LOW)
        GPIO.output(self.Motor1B,GPIO.HIGH)

        GPIO.output(self.Motor2A,GPIO.LOW)
        GPIO.output(self.Motor2B,GPIO.HIGH)
        
        # Publicar la velocidad actual en el tópico /robot_cmdVel
        cmd_vel_msg = Twist()
        cmd_vel_msg.linear.x = self.lineal_vel
        cmd_vel_msg.angular.z = 0.0
        self.cmd_vel_pub.publish(cmd_vel_msg)


    def atras(self):
        print("El robot se esta moviendo para atras")

        self.pwm_motor1.ChangeDutyCycle(self.lineal_vel * 100)
        self.pwm_motor2.ChangeDutyCycle(self.lineal_vel * 100)

        GPIO.output(self.Motor1A,GPIO.HIGH)
        GPIO.output(self.Motor1B,GPIO.LOW)

        GPIO.output(self.Motor2A,GPIO.HIGH)
        GPIO.output(self.Motor2B,GPIO.LOW)

        # Publicar la velocidad actual en el tópico /robot_cmdVel
        cmd_vel_msg = Twist()
        cmd_vel_msg.linear.x = -self.lineal_vel
        cmd_vel_msg.angular.z = 0.0
        self.cmd_vel_pub.publish(cmd_vel_msg)


    def girar_izquierda(self):
        print("El robot esta girando a la izquierda")

        self.pwm_motor1.ChangeDutyCycle(self.angular_vel * 100)
        self.pwm_motor2.ChangeDutyCycle(self.angular_vel * 100)

        GPIO.output(self.Motor1A,GPIO.HIGH)
        GPIO.output(self.Motor1B,GPIO.HIGH)

        GPIO.output(self.Motor2A,GPIO.LOW)
        GPIO.output(self.Motor2B,GPIO.HIGH)

        # Publicar la velocidad actual en el tópico /robot_cmdVel
        cmd_vel_msg = Twist()
        cmd_vel_msg.linear.x = 0.0
        cmd_vel_msg.angular.z = self.angular_vel
        self.cmd_vel_pub.publish(cmd_vel_msg)


    def girar_derecha(self):
        print("El robot esta girando a la derecha")
        self.pwm_motor1.ChangeDutyCycle(self.angular_vel * 100)
        self.pwm_motor2.ChangeDutyCycle(self.angular_vel * 100)

        GPIO.output(self.Motor1A,GPIO.LOW)
        GPIO.output(self.Motor1B,GPIO.HIGH)

        GPIO.output(self.Motor2A,GPIO.HIGH)
        GPIO.output(self.Motor2B,GPIO.HIGH)

        # Publicar la velocidad actual en el tópico /robot_cmdVel
        cmd_vel_msg = Twist()
        cmd_vel_msg.linear.x = 0.0
        cmd_vel_msg.angular.z = -self.angular_vel
        self.cmd_vel_pub.publish(cmd_vel_msg)


    def stop_motors(self):
        print("El robot se detiene")

        self.pwm_motor1.ChangeDutyCycle(0)
        self.pwm_motor2.ChangeDutyCycle(0)

        GPIO.output(self.Motor1B, GPIO.LOW)
        GPIO.output(self.Motor2B, GPIO.LOW)


        # Publicar la velocidad actual en el tópico /robot_cmdVel
        cmd_vel_msg = Twist()
        cmd_vel_msg.linear.x = 0.0
        cmd_vel_msg.angular.z = 0.0
        self.cmd_vel_pub.publish(cmd_vel_msg)


    def move_robot_callback(self, request, response):
        
        print('hola2')
        try:
            with open(request.filepath, 'r') as file:
                movements = file.read().splitlines()
                self.velocidad_lineal=float(movements[0])
                self.velocidad_angular=float(movements[1])
                for movement in movements[2:]:
                    if movement[0] == 'q':
                        self.girar_izquierda()
                        '''self.vel.angular.z=-self.velocidad_angular
                        self.cmd_velPublisher.publish(self.vel)'''
                        tic=time.perf_counter()
                        self.centinela=True
                        while self.centinela==True:
                            toc=time.perf_counter()
                            if toc-tic>float(movement[2:]):
                                self.centinela=False
                        self.stop_motors()
                        '''self.vel.angular.z=0.0
                        self.cmd_velPublisher.publish(self.vel)'''
                    elif movement[0] == 'w':
                        self.adelante()
                        '''self.vel.linear.x=self.velocidad_lineal
                        self.cmd_velPublisher.publish(self.vel)'''
                        tic=time.perf_counter()
                        self.centinela=True
                        while self.centinela==True:
                            toc=time.perf_counter()
                            if toc-tic>float(movement[2:]):
                                self.centinela=False
                        print('test   1')
                        self.stop_motors()
                        '''self.vel.linear.x=0.0
                        self.cmd_velPublisher.publish(self.vel)'''
                    elif movement[0] == "e":
                        self.girar_derecha()
                        '''self.vel.angular.z=self.velocidad_angular
                        self.cmd_velPublisher.publish(self.vel)'''
                        tic=time.perf_counter()
                        self.centinela=True
                        while self.centinela==True:
                            toc=time.perf_counter()
                            if toc-tic>float(movement[2:]):
                                self.centinela=False
                        self.stop_motors()
                        '''self.vel.angular.z=0.0
                        self.cmd_velPublisher.publish(self.vel)'''
                    elif movement[0] == "s":
                        self.atras()
                        '''self.vel.linear.x=-self.velocidad_lineal
                        self.cmd_velPublisher.publish(self.vel)'''
                        tic=time.perf_counter()
                        self.centinela=True
                        while self.centinela==True:
                            toc=time.perf_counter()
                            if toc-tic>float(movement[2:]):
                                self.centinela=False
                        self.stop_motors()
                        '''self.vel.linear.x=0.0
                        self.cmd_velPublisher.publish(self.vel)'''
                    else:
                        print('No se pudo.')
                    
                print('No se puede.')
        except FileNotFoundError:
            print('Archivo no encontrado.')


def main(args=None):
    rclpy.init(args=args)

    turtlebot = TurtleBotPlayer()

    rclpy.spin(turtlebot)

    # Destroy the node explicitly
    # (optional - otherwise it will be done automatically
    # when the garbage collector destroys the node object)
    turtlebot.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    print("Node initialized")
    main()