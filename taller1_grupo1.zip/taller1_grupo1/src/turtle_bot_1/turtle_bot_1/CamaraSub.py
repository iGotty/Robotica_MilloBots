import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from std_msgs.msg import String
from cv_bridge import CvBridge
import cv2
import numpy as np
import matplotlib.pyplot as plt
import statistics
import pytesseract

class ImageSubscriber(Node):
    def __init__(self, name):
        super().__init__(name)
        self.sub = self.create_subscription(Image, '/image_raw', self.listener_callback, 1)
        self.publisher_ = self.create_publisher(String, '/Grupo6/vision', 10)
        self.cv_bridge = CvBridge()
        self.image_count = 0

    def color_detection(self, image):
        w,h = 2*int(image.shape[0]/3), image.shape[0]
        image = image[2*int(image.shape[0]/3):,:,:]
        
        frameHSV = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)

        redBajo1 = np.array([0, 100, 20], np.uint8)
        redAlto1 = np.array([8, 255, 255], np.uint8)
        redBajo2=np.array([175, 100, 20], np.uint8)
        redAlto2=np.array([179, 255, 255], np.uint8)

        yellowBajo=np.array([15, 100, 20], np.uint8)
        yellowAlto=np.array([30, 255, 255], np.uint8)

        greenBajo=np.array([31, 100, 20], np.uint8)
        greenAlto=np.array([80, 255, 255], np.uint8)

        blueBajo=np.array([85, 100, 20], np.uint8)
        blueAlto=np.array([120, 255, 255], np.uint8)

        purpleBajo=np.array([130, 100, 20], np.uint8)
        purpleAlto=np.array([140, 255, 255], np.uint8)

        pinkBajo=np.array([145, 100, 20], np.uint8)
        pinkAlto=np.array([170, 255, 255], np.uint8)


        maskRed1 = cv2.inRange(frameHSV, redBajo1, redAlto1)
        maskRed2 = cv2.inRange(frameHSV, redBajo2, redAlto2)

        maskred = cv2.add(maskRed1, maskRed2), "Rojo"
        maskyellow = cv2.inRange(frameHSV, yellowBajo, yellowAlto), "Amarillo"
        maskgreen = cv2.inRange(frameHSV, greenBajo, greenAlto), "Verde"
        maskblue = cv2.inRange(frameHSV, blueBajo, blueAlto), "Azul"
        maskpurple = cv2.inRange(frameHSV, purpleBajo, purpleAlto), "Morado"
        maskpink = cv2.inRange(frameHSV, pinkBajo, pinkAlto), "Rosado"

        mayor = 0, "-1"
        for mask in [maskred, maskyellow, maskpurple, maskpink, maskgreen, maskblue]:
            if np.sum(mask[0]) > mayor[0]:
                mayor = np.sum(mask[0]), mask[1] 

        plt.text(w-150, h, mayor[1], fontsize=8, color='white')
        rect = plt.Rectangle((w-150, h-50), 170, 75, facecolor=(166/255, 56/255, 242/255), edgecolor=(166/255, 56/255, 242/255))
        plt.gca().add_patch(rect)

        cv2.imwrite(f'image_color_{0}.jpg', image)
        self.get_logger().info(f'Color: {mayor[1]}')
        return mayor[1]


    def figure_detection(self, image, show=False):
        image = image[:int(image.shape[0]/3),:,:]

        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        canny = cv2.Canny(gray, 10, 150)
        elipce = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 1))
        cruz = cv2.getStructuringElement(cv2.MORPH_CROSS, (1, 1))
        canny = cv2.dilate(canny, cruz, iterations=2)
        canny = cv2.erode(canny, elipce, iterations=3)
        canny = cv2.dilate(canny, cruz, iterations=2)
        cruz = cv2.getStructuringElement(cv2.MORPH_CROSS, (1, 1))
        canny = cv2.erode(canny, cruz, iterations=1)
        canny = cv2.dilate(canny, elipce, iterations=2)

        cnts,_ = cv2.findContours(canny, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        figuras = []
        fonts = 10
        lados = -1
        for c in cnts:
            epsilon = 0.03*cv2.arcLength(c,True)
            approx = cv2.approxPolyDP(c,epsilon,True)
            area = cv2.contourArea(approx)
            lados = len(approx)

            if area < 5000:
                continue

            x,y,w,h = cv2.boundingRect(approx)

            roi = image[y:y + h, x:x + w]
            gray_roi = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)

            if cv2.countNonZero(gray_roi) > 0:
                # Hay píxeles que no son blancos en la ROI, saltar al siguiente contorno
                pass

            else:
                continue


            if len(approx)==3:
                figura = 'Figura de 3 lados'
            elif len(approx)==4:
                figura = 'Figura de 4 lados'
            elif len(approx)==5:
                figura = 'Figura de 5 lados'
            elif len(approx)==6:
                figura = 'Figura de 6 lados'
            else:
                figura = 'Figura de infinitos lados'

            figuras.append(figura)

            print(figura, area)
            plt.text(w, h-200, figura, fontsize=8, color='white')
            rect = plt.Rectangle((w, h-250), 420, 75, facecolor=(166/255, 56/255, 242/255), edgecolor=(166/255, 56/255, 242/255))
            cv2.drawContours(image, [approx], 0, (166, 56, 242),2)
            plt.gca().add_patch(rect)
            cv2.imwrite(f'image_figura_{lados}.jpg', image)

        if show:
            canny = cv2.cvtColor(canny, cv2.COLOR_BGR2RGB)
            image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            plt.subplot(1, 2, 1)
            plt.imshow(canny)
            plt.axis('off')
            plt.subplot(1, 2, 2)
            plt.imshow(image)
            plt.axis('off')
            plt.show()

        moda = -1
        try:
            moda = statistics.mode(figuras)

            self.get_logger().info(f'Moda de figuras: {moda}')
        except:
            pass

        return moda
    

    def obtener_texto_imagen(self, image):

        image = image[int(image.shape[0]/3):2*int(image.shape[0]/3),:,:]
        # Convertir la imagen a escala de grises
        imagen_gris = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        cv2.imwrite(f'image_texto_{"gris"}.jpg', imagen_gris)
            # Filtrado de ruido con filtro de mediana
        imagen_filtrada = cv2.medianBlur(imagen_gris, 3)
        cv2.imwrite(f'image_texto_{"filtro"}.jpg', imagen_filtrada)

        # Mejora del contraste con ecualización del histograma
        imagen_ecualizada = cv2.equalizeHist(imagen_filtrada)
        cv2.imwrite(f'image_texto_{"hist"}.jpg', imagen_ecualizada)

    

        # Aplicar un umbral para resaltar el texto
        _, imagen_umbral = cv2.threshold(imagen_gris, 70, 180, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        cv2.imwrite(f'image_texto_{"umbral"}.jpg', imagen_umbral)
        # Realizar la extracción de texto utilizando pytesseract
        texto = pytesseract.image_to_string(imagen_gris)
        self.get_logger().info(f'Texto: {texto}')

        return texto


    

    def listener_callback(self, data):
        image = self.cv_bridge.imgmsg_to_cv2(data, 'bgr8')
        texto = self.obtener_texto_imagen(image)
        figura = self.figure_detection(image)
        color = self.color_detection(image)
        msg = String()
        msg.data =  "1"+","+str(texto)+","+str(color)+","+str(figura)
        self.publisher_.publish(msg)

       

def main(args=None):
    rclpy.init(args=args)
    node = ImageSubscriber("topic_webcam_sub")
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
