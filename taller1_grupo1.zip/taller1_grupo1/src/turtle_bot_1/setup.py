from setuptools import setup

package_name = 'turtle_bot_1'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='robotica',
    maintainer_email='robotica@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'Turtle_Bot_Teleop = turtle_bot_1.Turtle_Bot_Teleop:main',
            'Turtle_Bot_CarController = turtle_bot_1.Turtle_Bot_CarController:main',
            'Turtle_Bot_KeyPublisher = turtle_bot_1.Turtle_Bot_KeyPublisher:main',
            'Turtle_Bot_txt_CarController = turtle_bot_1.Turtle_Bot_txt_CarController:main',
            'New_Teleop = turtle_bot_1.New_Teleop:main',
            'Movimiento = turtle_bot_1.Movimiento:main',
            'Brazo = turtle_bot_1.Brazo:main',
            'Camara_Pub = turtle_bot_1.CamaraPub:main',
	    'Camara_Sub = turtle_bot_1.CamaraSub:main'
        ],
    },
)
