from setuptools import setup

package_name = 'turtle_bot_1'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='robotica',
    maintainer_email='robotica@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'Turtle_Bot_Teleop = turtle_bot_1.Turtle_Bot_Teleop:main',
            'Turtle_Bot_CarController = turtle_bot_1.Turtle_Bot_CarController:main',
            'Turtle_Bot_interface = turtle_bot_1.Turtle_Bot_interface:main',
            'Turtle_Bot_savekey = turtle_bot_1.Turtle_Bot_savekey:main',
            'Brazo = turtle_bot_1.Brazo:main',
            'Turtle_Bot_Nodo_Interfaz = turtle_bot_1.Nodo_interfaz_mani:main',
            'Turtle_Bot_Save_Angle = turtle_bot_1.Nodo_SaveAngle:main',
            'Turtle_Bot_Camara_Sub = turtle_bot_1.CamaraSub:main',
            'Turtle_Bot_Camara_Pub = turtle_bot_1.CamaraPub:main',
            'Nodo_SaveBaner = turtle_bot_1.Nodo_SaveBaner:main',
            'nodo_navegacion = turtle_bot_1.nodo_navegacion:main'

        ],
    },
)
